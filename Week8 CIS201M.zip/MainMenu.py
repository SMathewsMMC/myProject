0        1         2         3         4         5         6         7         8
01234567890123456789012345678901234567890123456789012345678901234567890123456789

ProjectName: How_Do_I_Do_A_Program                        Author: Sean Mathews 
MenuScreen                                                  Date: Oct 24, 2020 
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                          CIS-210M Class Assigmnents                            
                   This is a list of completed assignments                      
																	
                        A) Timer.py                                             
                        B) RandGen.py
                        C) Stack.py
						                                                        
                        Q) Quit



                   Make a selection from the options above                      
				                                                                

