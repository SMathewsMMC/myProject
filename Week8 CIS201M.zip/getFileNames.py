'''
0         1         2         3         4         5         6         7         8
012345678901234567890123456789012345678901234567890123456789012345678901234567890

   ProjectName:  How_Do_I_Do_A_Program                                                
   ProgramName:  getFileNames.py                                                 
   Author:       Sean Mathews                                    
   Date:         10/24/2020                                          
   Synopsis:
       This set of programs are the various assigments done in CIS-210M

   def getTestMenu():Returns TestMenu.py to be used as the MainScreen.
   def getTimer():Returns Timer.py program that is time
   def getRandGen():Returns the Random Number Generator
   def getStack():Returns a program that creates a Stack
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   
'''
#A function returned something

def getTestMenu():
    return 'C:\\MyProgramFiles\\TestMenu.txt'

def getTimer():
    return 'C:\\MyProgramFiles\\Timer.txt'

def getRandGen():
    return 'C:\MyProgramFiles\\RandGen.txt'

def getStack():
    return 'C:\\MyProgramFiles\\Stack.txt'

def getMainMenu():
    return 'C:\\MyProgramFiles\\MainMenu.txt'
