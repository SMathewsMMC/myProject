'''
   ProjectName:  How_Do_I_Do_A_Program                                                
   ProgramName:  Driver.py                                                 
   Author:       Sean Mathews                                    
   Date:         10/24/2020                                          
   Synopsis:
          This is what will be used to drive the program.

   def main(): This is where most of my processess will be initiated.
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   
'''
import FileReader as fr
import getFileNames as gfn
import os # To clear the cmd line screen


def printOutAList(theList, startCt, endCt): #process or procedure to print a list.
    os.system("cls")
    for i in range(startCt, endCt):
        print(theList[i])


def convertAValue(menu, theList):
    pass


def main():
    menu = fr.readTheFileIn(gfn.getMainMenu())
    timer = fr.readTheFileIn(gfn.getTimer())
    rand = fr.readTheFileIn(gfn.getRandGen())
    stack = fr.readTheFileIn(gfn.getStack())
    os.system("cls")
    input(timer)
    os.system("cls")
    input(rand)
    os.system("cls")
    input(stack)
    print(menu)
    printOutAList(menu, 1, len(menu))

#####################
main()
