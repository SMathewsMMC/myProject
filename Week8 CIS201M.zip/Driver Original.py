'''

   ProjectName:  How_Do_I_Do_A_Program                                                
   ProgramName:  Driver.py                                                 
   Author:       Sean Mathews                                    
   Date:         TodaysDate                                          
   Synopsis:
          This is what will be used to drive the program.

   def main(): This is where most of my processess will be initiated.
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   def A():mty
   
'''
import someFile as abc

def main():
    abc.something()
    print(something)